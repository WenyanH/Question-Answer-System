# __all__ = ["data", "errors", "lexicon", "settings", "text", "utilities"]

from data import *
